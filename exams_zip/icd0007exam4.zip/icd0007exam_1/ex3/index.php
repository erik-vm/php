<?php

$subTemplatePath = 'content1.php';
$content = 'Page 1';

include 'main.php';
