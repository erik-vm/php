<p>Template 2</p>

<section>
    <?= $content ?>
</section>
