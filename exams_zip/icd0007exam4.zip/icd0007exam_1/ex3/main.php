<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<nav>
    <?php include('nav.html') ?>
</nav>

<br>

<div>
    <?php include($subTemplatePath) ?>
</div>


</body>
</html>
