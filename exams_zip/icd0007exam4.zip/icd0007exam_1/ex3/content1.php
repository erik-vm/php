<p>Template 1</p>

<section>
    <?= $content ?>
</section>
