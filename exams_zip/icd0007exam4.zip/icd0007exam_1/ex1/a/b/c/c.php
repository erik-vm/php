<?php

require_once '../../a.html';