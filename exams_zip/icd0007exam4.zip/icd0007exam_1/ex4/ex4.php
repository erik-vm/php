<?php

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/Student.php';

function getStudentInfo(): array {

    $conn = getConnectionWithData(__DIR__ . '/data.sql');

    $stmt = $conn->prepare('... päring tuleb siia ...');

    $stmt->execute();

    // kood tuleb siia

    return [];
}
