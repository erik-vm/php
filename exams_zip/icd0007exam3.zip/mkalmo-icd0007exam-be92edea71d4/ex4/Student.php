<?php

class Student {
    public string $name;
    public string $sd;

    public function __construct($name, $sd) {
        $this->name = $name;
        $this->sd = $sd;
    }
}

