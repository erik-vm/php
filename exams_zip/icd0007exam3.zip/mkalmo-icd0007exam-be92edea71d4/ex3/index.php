<?php

require_once '../vendor/tpl.php';


print renderTemplate('main.html',
    ['fileName' => 'content1.html']);
