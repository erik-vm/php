<?php

require_once __DIR__ . '/../vendor/php-test-framework/public-api.php';
require_once __DIR__ . '/WeatherStation.php';

function weatherStationStoresAndProvidesTemperatureInfo() {
    $station = new WeatherStation();

    $station->addTemperatureReading(10.0);
    $station->addTemperatureReading(8.0);
    $station->addTemperatureReading(13.0);
    $station->addTemperatureReading(9.0);

    assertThat($station->getLastTemperatureReading(), is(9.0));
    assertThat($station->getLowestTemperatureReading(), is(8.0));
    assertThat($station->getHighestTemperatureReading(), is(13.0));
}

function storesReadingsPermanently() {
    $station = new WeatherStation();

    $station->addTemperatureReading(13.0);
    $station->addTemperatureReading(8.0);

    $station = new WeatherStation(true);

    $station->addTemperatureReading(10.0);

    assertThat($station->getLastTemperatureReading(), is(10.0));
    assertThat($station->getLowestTemperatureReading(), is(8.0));
    assertThat($station->getHighestTemperatureReading(), is(13.0));
}

#Helpers

stf\runTests(getPointsReporter([
    1 => 5,
    2 => 10]));
