<?php

const STATE_FILE_NAME = 'state.data';

class WeatherStation {

    public function __construct(bool $restoreState = false) {
    }

    public function addTemperatureReading(float $temperature): void {
        throw new Error('not implemented yet');
    }

    public function getLastTemperatureReading(): float {
        throw new Error('not implemented yet');
    }

    public function getLowestTemperatureReading(): float {
        throw new Error('not implemented yet');
    }

    public function getHighestTemperatureReading(): float {
        throw new Error('not implemented yet');
    }
}