<?php

require_once 'WeatherStation.php';

$station = new WeatherStation();

$station->addTemperatureReading(10);
$station->addTemperatureReading(8);
$station->addTemperatureReading(13);
$station->addTemperatureReading(9);

print $station->getLowestTemperatureReading() . PHP_EOL; // 8
print $station->getHighestTemperatureReading() . PHP_EOL; // 13
print $station->getLastTemperatureReading() . PHP_EOL; // 9

