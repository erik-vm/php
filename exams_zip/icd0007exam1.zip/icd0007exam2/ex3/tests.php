<?php

require_once __DIR__ . '/../vendor/php-test-framework/public-api.php';

const BASE_URL = 'http://localhost:8080/ex3/';

function defaultPageIsFrom() {
    navigateTo(BASE_URL);

    assertPageContainsRadioWithName('color');
}

function formSubmissionRedirects() {
    navigateTo(BASE_URL);

    disableAutomaticRedirects();

    clickButton('button');

    assertThat(getResponseCode(), isAnyOf(301, 302, 303));
}

function redirectUrlIsCorrect() {
    navigateTo(BASE_URL);

    clickButton('button');

    assertThat(getCurrentUrl(), containsString('?color=red'));
}

function pageContentIsCorrect() {
    navigateTo(BASE_URL);

    clickButton('button');

    assertThat(getPageText(), containsString('Valitud värv: Punane'));

    assertPageContainsLinkWithId('back-link');
}

setBaseUrl(BASE_URL);

stf\runTests(new stf\PointsReporter([
    2 => 8,
    3 => 15,
    4 => 20]));
