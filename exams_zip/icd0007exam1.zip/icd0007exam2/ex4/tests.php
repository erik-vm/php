<?php

require_once __DIR__ . '/../vendor/php-test-framework/public-api.php';
require_once __DIR__ . '/ex4.php';

function personCountIsCorrect() {

    $personList = getPersonList();

    assertThat(count($personList), is(4));
}

function orderIsCorrect() {
    $personList = getPersonList();
    assertThat(count($personList), is(4));

    assertThat($personList[0]->name, is('Alice'));
    assertThat($personList[1]->name, is('Alice'));
    assertThat($personList[2]->name, is('Bob'));
    assertThat($personList[3]->name, is('Carol'));
}

function eachPersonHasCorrectNumbers() {
    $personList = getPersonList();
    assertThat(count($personList), is(4));

    assertThat($personList[0]->phones, contains(['n1', 'n2']));
    assertThat($personList[1]->phones, contains(['n5']));
    assertThat($personList[2]->phones, contains(['n3']));
    assertThat($personList[3]->phones, contains(['n4']));
}

stf\runTests(new stf\PointsReporter([
    1 => 5,
    2 => 10,
    3 => 25]));
