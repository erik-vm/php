<?php

require_once 'Person.php';

getPersonList();

function getPersonList() : array {
    $conn = getConnectionWithData(__DIR__ . '/data.sql');

    $stmt = $conn->prepare('SELECT id, name, number 
                               FROM person 
                               LEFT JOIN phone ON id = person_id ORDER BY name, id');

    $stmt->execute();

    foreach ($stmt as $row) {
        $id = $row['id'];

        // ...

    }

    return [];
}













function getConnectionWithData($dataFile) : PDO {
    $conn = new PDO('sqlite::memory:');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $contents = join('', file($dataFile));

    $statements = explode(';', $contents);

    foreach ($statements as $statement) {
        $conn->prepare($statement)->execute();
    }

    return $conn;
}
