<?php

class Person {
    public int $id;
    public string $name;
    public array $phones = [];

    public function __construct($id, $name) {
        $this->id = $id;
        $this->name = $name;
    }

    public function addPhone($phone) {
        $this->phones[] = $phone;
    }
}

