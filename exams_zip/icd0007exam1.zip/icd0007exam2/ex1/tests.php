<?php

require_once __DIR__ . '/../vendor/php-test-framework/public-api.php';

const BASE_URL = 'http://localhost:8080/ex1/';

function indexToB() {
    navigateTo(BASE_URL);

    clickRelativeLinkWithText("b.html");

    assertCurrentUrl(BASE_URL . "a/b/b.html");
}

function bToE() {
    navigateTo(BASE_URL . '/a/b/b.html');

    clickRelativeLinkWithText("e.html");

    assertCurrentUrl(BASE_URL . "a/b/c/d/e/e.html");
}

function eToD() {
    navigateTo(BASE_URL . 'a/b/c/d/e/e.html');

    clickRelativeLinkWithText("d.html");

    assertCurrentUrl(BASE_URL . "a/b/c/d/d.html");
}

function dToB() {
    navigateTo(BASE_URL . 'a/b/c/d/d.html');

    clickRelativeLinkWithText("b.html");

    assertCurrentUrl(BASE_URL . "a/b/b.html");
}

function shortestSelf() {

    navigateTo(BASE_URL . 'a/b/c/c.html');

    $linkText = "shortest self";

    $href = getHrefFromLinkWithText($linkText);

    clickLinkWithText($linkText);

    assertCurrentUrl(BASE_URL . "a/b/c/c.html");

    assertThat(strlen($href), is(0),
        sprintf("'%s' is not the shortest link possible", $href));
}

function shortestCIndex() {

    navigateTo(BASE_URL . 'a/b/c/c.html');

    $linkText = "shortest c/index.html";

    $href = getHrefFromLinkWithText($linkText);

    clickLinkWithText($linkText);

    assertCurrentUrl(BASE_URL . "a/b/c/");

    assertThat(strlen($href), is(1),
        sprintf("'%s' is not the shortest link possible", $href));
}

#Helpers

function clickRelativeLinkWithText($linkText) {
    $href = getHrefFromLinkWithText($linkText);

    if (preg_match("/:/", $href) || preg_match("/^\//", $href)) {
        throw new RuntimeException("$href is not a relative link");
    }

    clickLinkWithText($linkText);
}

setBaseUrl(BASE_URL);

stf\runTests(new stf\PointsReporter([
    1 => 1,
    2 => 2,
    3 => 3,
    4 => 4,
    6 => 6]));
