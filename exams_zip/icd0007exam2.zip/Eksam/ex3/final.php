<section>
    Valitud värv: <?= $color ?>
</section>
