<section>
    Olete kindel?
</section>

<br>
<br>

<form method="post">
    <input type="hidden" name="color" value="<?= $color ?>" />

    <button type="submit" name="confirm" value="no">Ei</button>
    <button type="submit" name="confirm" value="yes">Jah</button>
</form>
