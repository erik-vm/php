<?php

$translations = ['red' => 'Punane', 'blue' => 'Sinine'];

$subTemplatePath = 'form.php';

include('main.php');
