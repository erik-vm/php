<form method="post">

    Palun valige värv<br><br>

    Punane: <input type="radio" name="color"
                   value="red" <?= $color === 'red' ? 'checked' : '' ?> >
    Sinine: <input type="radio" name="color" value="blue"
                               <?= $color === 'blue' ? 'checked' : '' ?> >

    <br>
    <br>

    <button type="submit" name="cmd" value="select">Edasi</button>

</form>