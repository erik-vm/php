<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>

<div>
    <?php include($subTemplatePath) ?>
</div>

</body>
</html>
