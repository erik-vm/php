<?php

require_once __DIR__ . '/../vendor/php-test-framework/public-api.php';
require_once __DIR__ . '/ex4.php';

function categoryNamesAreCorrect() {

    $categoryList = getCategoryList();

    assertThat(count($categoryList), is(3));

    $categoryNames = getCategoryNames($categoryList);

    assertThat($categoryNames, containsInAnyOrder(['cat4', 'cat5', 'cat6']));
}

function eachCategoryContainsCorrectProducts() {

    $categoryList = getCategoryList();

    $cat4Products = getProductNumbersByCategoryName($categoryList, 'cat4');
    $cat5Products = getProductNumbersByCategoryName($categoryList, 'cat5');
    $cat6Products = getProductNumbersByCategoryName($categoryList, 'cat6');

    assertThat($cat4Products, containsInAnyOrder(['p3', 'p6', 'p7']));
    assertThat($cat5Products, containsInAnyOrder(['p1', 'p2', 'p5']));
    assertThat($cat6Products, containsInAnyOrder(['p4', 'p8']));
}

#Helpers

function getProductNumbersByCategoryName($categoryList, $categoryName): array {
    foreach ($categoryList as $category) {
        if ($category->name !== $categoryName) {
            continue;
        }

        return array_map(function ($each) {
            return $each->number;
        }, $category->getProducts());
    }

    throw new RuntimeException('did not find category: ' . $categoryName);
}

function getCategoryNames($categoryList): array {
    return array_values(array_map(function ($each) {
        return $each->name;
    }, $categoryList));
}


stf\runTests(new stf\PointsReporter([
    1 => 5,
    2 => 17]));
