<?php

require_once 'Category.php';
require_once 'Product.php';

function getCategoryList() : array {
    $conn = getConnectionWithData(__DIR__ . '/data.sql');

    $stmt = $conn->prepare('SELECT p.id, product_number, name 
                            FROM products p
                            left join categories c on category_id = c.id');

    $stmt->execute();

    $categoryList = [];

    // kood tuleb siia

    return $categoryList; // Category objektide list (mitte sõnastik vms.)
}













function getConnectionWithData($dataFile) : PDO {
    $conn = new PDO('sqlite::memory:');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $contents = join('', file($dataFile));

    $statements = explode(';', $contents);

    foreach ($statements as $statement) {
        $conn->prepare($statement)->execute();
    }

    return $conn;
}
